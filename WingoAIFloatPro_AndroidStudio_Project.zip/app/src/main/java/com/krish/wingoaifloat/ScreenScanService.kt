package com.krish.wingoaifloat
import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean
class ScreenScanService:Service() {
 private var projection:MediaProjection?=null;private var display:VirtualDisplay?=null;private var reader:ImageReader?=null
 private var thread:HandlerThread?=null;private var handler:Handler?=null;private val busy=AtomicBoolean(false)
 private val recognizer by lazy{TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)}
 override fun onBind(i:Intent?):IBinder?=null
 override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int {
  notifyRunning()
  val code=i?.getIntExtra("resultCode",Activity.RESULT_CANCELED)?:return START_NOT_STICKY
  val data=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra("projectionData",Intent::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra("projectionData")
  if(data==null){stopSelf();return START_NOT_STICKY}
  projection=(getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code,data)
  capture();return START_STICKY
 }
 private fun notifyRunning() {
  val id="wingo_capture"
  if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(id,"Wingo screen scan",NotificationManager.IMPORTANCE_LOW))
  val n=if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,id) else Notification.Builder(this)
  startForeground(77,n.setContentTitle("Wingo AI screen scan").setContentText("On-device text recognition active").setSmallIcon(android.R.drawable.ic_menu_view).build())
 }
 private fun capture() {
  val m=DisplayMetrics();@Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
  val w=m.widthPixels;val h=m.heightPixels
  thread=HandlerThread("WingoOCR").also{it.start()};handler=Handler(thread!!.looper)
  reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
  reader!!.setOnImageAvailableListener({r->
   val image=r.acquireLatestImage()?:return@setOnImageAvailableListener
   if(!busy.compareAndSet(false,true)){image.close();return@setOnImageAvailableListener}
   try {
    val plane=image.planes[0];val paddedWidth=w+(plane.rowStride-plane.pixelStride*w)/plane.pixelStride
    val padded=Bitmap.createBitmap(paddedWidth,h,Bitmap.Config.ARGB_8888);padded.copyPixelsFromBuffer(plane.buffer)
    val bitmap=Bitmap.createBitmap(padded,0,0,w,h);padded.recycle();image.close()
    recognizer.process(InputImage.fromBitmap(bitmap,0)).addOnSuccessListener{result->
     // Prototype OCR: isolated digits anywhere on screen can be unrelated. Verify them.
     Regex("(?<!\\\\d)([0-9])(?!\\\\d)").findAll(result.text).mapNotNull{it.groupValues[1].toIntOrNull()}.lastOrNull()?.let{Stats.add(this,it)}
    }.addOnCompleteListener{bitmap.recycle();busy.set(false)}
   }catch(_:Exception){try{image.close()}catch(_:Exception){};busy.set(false)}
  },handler)
  display=projection?.createVirtualDisplay("WingoScreen",w,h,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
 }
 override fun onDestroy(){display?.release();reader?.close();projection?.stop();thread?.quitSafely();try{recognizer.close()}catch(_:Exception){};super.onDestroy()}
}
