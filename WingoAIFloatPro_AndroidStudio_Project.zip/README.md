# Wingo AI Float Pro — Android Studio starter

## Build an APK
Open this folder in Android Studio (Hedgehog or newer), let Gradle sync, then choose
**Build > Build APK(s)**. Install the generated debug APK on your Android phone.

## Use
1. Grant **Display over other apps** permission.
2. Tap **Enable floating window**.
3. Tap **Start screen scan** and approve Android's screen-capture prompt.
4. Switch to the game. The small draggable bubble stays on top; tap to expand.
5. Use **Stop floating + scan** to stop.

## Prototype limitations
- OCR scans visible text but currently extracts isolated digits from the whole screen.
  It can mistake balances, timers, or bet amounts for results. Verify every captured result.
- This is an on-device historical-frequency demo, not a reliable next-round predictor.
  Random outcomes cannot be guaranteed from previous results.
- Android version/device policies may restrict screen capture and background operation.
- Production version needs a selectable result-strip crop, OCR confidence checks,
  round-ID deduplication, a complete dashboard and device testing.
- No betting automation or private game API access is included.
