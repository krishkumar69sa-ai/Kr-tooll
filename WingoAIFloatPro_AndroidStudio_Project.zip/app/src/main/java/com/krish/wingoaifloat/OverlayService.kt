package com.krish.wingoaifloat
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Typeface
class OverlayService:Service() {
 private lateinit var wm:WindowManager; private var root:View?=null; private var expanded=false
 private lateinit var lp:WindowManager.LayoutParams; private lateinit var detail:TextView
 override fun onBind(i:Intent?):IBinder?=null
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int { show(); return START_STICKY }
 private fun show() {
  if(root!=null)return
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val box=LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(14,10,14,10); setBackgroundColor(Color.rgb(24,34,50)) }
  val title=TextView(this).apply { text="W AI";textSize=13f;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER }
  detail=TextView(this).apply { text="Tap to view";textSize=11f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;visibility=View.GONE }
  box.addView(title);box.addView(detail)
  box.setOnTouchListener(object:View.OnTouchListener {
   var x=0f;var y=0f;var sx=0;var sy=0;var moved=false
   override fun onTouch(v:View,e:MotionEvent):Boolean { when(e.action) {
    MotionEvent.ACTION_DOWN->{x=e.rawX;y=e.rawY;sx=lp.x;sy=lp.y;moved=false;return true}
    MotionEvent.ACTION_MOVE->{val dx=(e.rawX-x).toInt();val dy=(e.rawY-y).toInt();if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8)moved=true;lp.x=sx+dx;lp.y=sy+dy;wm.updateViewLayout(box,lp);return true}
    MotionEvent.ACTION_UP->{if(!moved){expanded=!expanded;detail.visibility=if(expanded)View.VISIBLE else View.GONE;refresh()};return true}
   };return false }
  })
  lp=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
   WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT)
  lp.gravity=Gravity.TOP or Gravity.END;lp.x=16;lp.y=220
  root=box;wm.addView(box,lp);refresh()
 }
 private fun refresh() {
  val s=Stats.summary(this);val n=s.optInt("total")
  detail.text=if(n<5)"Need more results ($n/5)" else "History estimate\\n${s.optString("color")} • ${s.optString("size")}\\nMost frequent: ${s.optInt("best")}\\nSamples: $n\\nNot guaranteed"
 }
 override fun onDestroy(){root?.let{try{wm.removeView(it)}catch(_:Exception){}};root=null;super.onDestroy()}
 companion object { const val SHOW="SHOW" }
}
