package com.krish.wingoaifloat
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
object Stats {
 private const val PREF="wingo_stats"; private const val KEY="results"
 fun add(c:Context,n:Int) {
  if(n !in 0..9) return
  val p=c.getSharedPreferences(PREF,0); val old=JSONArray(p.getString(KEY,"[]"))
  if(old.length()>0 && old.optInt(old.length()-1,-1)==n) return
  val next=JSONArray(); for(i in maxOf(0,old.length()-199) until old.length()) next.put(old.optInt(i))
  next.put(n); p.edit().putString(KEY,next.toString()).apply()
 }
 fun summary(c:Context):JSONObject {
  val a=JSONArray(c.getSharedPreferences(PREF,0).getString(KEY,"[]")); val counts=IntArray(10)
  for(i in 0 until a.length()) { val n=a.optInt(i,-1); if(n in 0..9) counts[n]++ }
  val best=counts.indices.maxByOrNull{counts[it]} ?: 0
  val big=(5..9).sumOf{counts[it]}; val small=(0..4).sumOf{counts[it]}
  return JSONObject().put("total",counts.sum()).put("best",best).put("counts",JSONArray(counts.toList()))
   .put("size",if(big>=small) "BIG" else "SMALL").put("color",colorFor(best))
 }
 fun colorFor(n:Int)=when(n){0,5->"VIOLET + RED/GREEN";1,3,7,9->"GREEN";else->"RED"}
}
