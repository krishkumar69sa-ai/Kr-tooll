package com.krish.wingoaifloat
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
 private val requestCode = 4102
 private lateinit var projectionManager: MediaProjectionManager
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  val box = LinearLayout(this).apply { orientation=1; setPadding(28,40,28,24); setBackgroundColor(Color.rgb(15,23,42)) }
  fun text(s:String, size:Float, color:Int=Color.WHITE)=TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0,10,0,14) }
  box.addView(text("WINGO AI FLOAT PRO",25f))
  box.addView(text("Small floating bubble with on-device screen text scanning and historical statistics. It cannot know or guarantee the next random result.",15f,Color.LTGRAY))
  box.addView(Button(this).apply { text="1. Enable floating window"; setOnClickListener {
   if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
   else startService(Intent(this@MainActivity,OverlayService::class.java).setAction(OverlayService.SHOW))
  }})
  box.addView(Button(this).apply { text="2. Start screen scan"; setOnClickListener {
   if (!Settings.canDrawOverlays(this@MainActivity)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))); return@setOnClickListener }
   startActivityForResult(projectionManager.createScreenCaptureIntent(),requestCode)
  }})
  box.addView(Button(this).apply { text="Stop floating + scan"; setOnClickListener {
   stopService(Intent(this@MainActivity,ScreenScanService::class.java)); stopService(Intent(this@MainActivity,OverlayService::class.java))
  }})
  box.addView(text("Use: grant overlay permission, start bubble, approve Android screen capture, then open the game. Tap bubble to expand. OCR may misread unrelated digits; verify history. Screen text is processed on-device.",13f,Color.LTGRAY))
  setContentView(box)
 }
 @Deprecated("Compatibility")
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==this.requestCode && resultCode==RESULT_OK && data!=null) {
   val i=Intent(this,ScreenScanService::class.java).putExtra("resultCode",resultCode).putExtra("projectionData",data)
   if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
   startService(Intent(this,OverlayService::class.java).setAction(OverlayService.SHOW))
  }
 }
}
